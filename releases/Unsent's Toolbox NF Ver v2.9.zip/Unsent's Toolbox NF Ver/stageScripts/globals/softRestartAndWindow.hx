import flixel.FlxG;
import flixel.FlxCamera;
import flixel.FlxSprite;
import flixel.util.FlxColor;
import flixel.util.FlxTimer;
import states.titleState.TitleState;

// ============================================================
// WideScreen 配置
// ============================================================

var wideScreenSetting:Bool = getModSetting("fullWindow") == true;
var wideScreenInitialized:Bool = false;

// 原始游戏尺寸
var originalWidth:Int = FlxG.width;
var originalHeight:Int = FlxG.height;

// 原始游戏位置
var originalGameX:Float = FlxG.game.x;
var originalGameY:Float = FlxG.game.y;

// 原始 ScaleMode
var originalDeviceWidth:Float = FlxG.scaleMode.deviceSize.x;
var originalDeviceHeight:Float = FlxG.scaleMode.deviceSize.y;
var originalGameSizeWidth:Float = FlxG.scaleMode.gameSize.x;
var originalGameSizeHeight:Float = FlxG.scaleMode.gameSize.y;
var originalScaleX:Float = FlxG.scaleMode.scale.x;
var originalScaleY:Float = FlxG.scaleMode.scale.y;
var originalOffsetX:Float = FlxG.scaleMode.offset.x;
var originalOffsetY:Float = FlxG.scaleMode.offset.y;

// 原始摄像机信息
var originalCameraStates:Array<Dynamic> = [];

// 设置变化检测
var settingChangeTimer:FlxTimer = null;
var pendingWideScreenSetting:Bool = false;

// ============================================================
// 保存原始摄像机
// ============================================================

function saveOriginalCameras():Void {
    originalCameraStates = [];

    if (FlxG.cameras == null)
        return;

    for (camera in FlxG.cameras.list) {
        originalCameraStates.push({
            camera: camera,
            width: camera.width,
            height: camera.height,
            scrollX: camera.scroll.x,
            scrollY: camera.scroll.y
        });
    }
}

// ============================================================
// 恢复原始显示状态
// ============================================================

function restoreOriginalDisplay():Void {
    try {
        FlxG.width = originalWidth;
        FlxG.height = originalHeight;

        var mode = FlxG.scaleMode;

        mode.deviceSize.set(originalDeviceWidth, originalDeviceHeight);
        mode.gameSize.set(originalGameSizeWidth, originalGameSizeHeight);
        mode.scale.set(originalScaleX, originalScaleY);
        mode.offset.set(originalOffsetX, originalOffsetY);

        FlxG.game.x = originalGameX;
        FlxG.game.y = originalGameY;

        for (data in originalCameraStates) {
            var camera:Dynamic = data.camera;
            if (camera == null) continue;

            camera.setSize(data.width, data.height);
            camera.scroll.set(data.scrollX, data.scrollY);
        }

        // 重新触发 Flixel 的窗口尺寸更新流程
        FlxG.scaleMode = mode;

        wideScreenInitialized = false;

        trace('[WideScreen] Original display restored');
        trace('[WideScreen] Game: ' + FlxG.width + 'x' + FlxG.height);
    } catch (e:Dynamic) {
        trace('[WideScreen] Restore error: ' + e);
    }
}

// ============================================================
// 初始化宽屏
// ============================================================

function initializeWideScreen():Void {

    var width = FlxG.stage.stageWidth;
    var height = FlxG.stage.stageHeight;

    if (width <= 0 || height <= 0)
        return;

    if (getModSetting("fullWindow") != true)
        return;

    // 保存当前原始状态
    saveOriginalCameras();

    var scale:Float = height / 720;
    var gameWidth:Int = Math.ceil(width / scale);

    FlxG.width = gameWidth;
    FlxG.height = 720;

    var mode = FlxG.scaleMode;

    mode.deviceSize.set(width, height);
    mode.gameSize.set(width, height);
    mode.scale.set(scale, scale);
    mode.offset.set(0, 0);

    if (FlxG.cameras != null) {
        for (camera in FlxG.cameras.list) {
            if (camera.width == originalWidth &&
                camera.height == originalHeight) {

                var cameraOldWidth = camera.width;

                camera.setSize(gameWidth, 720);
                camera.scroll.x -= (gameWidth - cameraOldWidth) * 0.5;
            }
        }
    }

    FlxG.game.x = 0;
    FlxG.game.y = 0;

    wideScreenInitialized = true;
}

// ============================================================
// 设置变化检测
// ============================================================

function checkWideScreenSetting():Void {
    var current:Bool = getModSetting("fullWindow") == true;

    if (current == wideScreenSetting)
        return;

    wideScreenSetting = current;
    pendingWideScreenSetting = current;

    // 如果之前存在等待中的重启，则取消
    if (settingChangeTimer != null) {
        settingChangeTimer.cancel();
        settingChangeTimer = null;
    }

    trace('[WideScreen] Setting changed: ' + current);
    trace('[WideScreen] Waiting 1.5 seconds');

    settingChangeTimer = new FlxTimer().start(1.5, function(timer) {
        settingChangeTimer = null;

        var latest:Bool = getModSetting("fullWindow") == true;

        if (latest != pendingWideScreenSetting) {
            trace('[WideScreen] Setting changed again, restart cancelled');
            return;
        }

        trace('[WideScreen] Setting unchanged, restarting');

        performSoftRestart();
    });
}

// ============================================================
// 软重启配置
// ============================================================

var restartHoldDuration:Float = 3000;
var restartBarMargin:Float = 12;
var restartBarHeight:Int = 12;
var restartBarBorder:Int = 2;

// ============================================================
// 软重启状态
// ============================================================

var restartHoldTime:Float = 0;
var restartProgressBar:FlxSprite = null;
var restartProgressBackground:FlxSprite = null;
var restartCamera:FlxCamera = null;

var restarting:Bool = false;
var waitingForTitleRestart:Bool = false;
var createdState:Dynamic = null;

// ============================================================
// 创建独立摄像机
// ============================================================

function createRestartCamera():Void {
    if (restartCamera != null)
        return;

    restartCamera = new FlxCamera();
    restartCamera.bgColor = FlxColor.TRANSPARENT;
    restartCamera.scroll.set(0, 0);
    restartCamera.target = null;

    FlxG.cameras.add(restartCamera, false);
}

// ============================================================
// 销毁独立摄像机
// ============================================================

function destroyRestartCamera():Void {
    if (restartCamera == null)
        return;

    try {
        FlxG.cameras.remove(restartCamera, true);
    } catch (e:Dynamic) {}

    restartCamera = null;
}

// ============================================================
// 获取重启按键
// ============================================================

function getRestartKey():String {
    var key:Dynamic = getModSetting("softRestartKey");

    if (key == null)
        return null;

    key = Std.string(key);

    if (key == "" || key == "Disable" || key == "None")
        return null;

    var keyMap:Map<String, String> = [
        "Space" => "SPACE",
        "Enter" => "ENTER",
        "Backspace" => "BACKSPACE",
        "Tab" => "TAB",
        "Escape" => "ESCAPE",
        "Insert" => "INSERT",
        "Delete" => "DELETE",
        "Home" => "HOME",
        "End" => "END",
        "Page Up" => "PAGEUP",
        "Page Down" => "PAGEDOWN",
        "Up" => "UP",
        "Down" => "DOWN",
        "Left" => "LEFT",
        "Right" => "RIGHT",
        "NumPad0" => "NUMPADZERO",
        "NumPad1" => "NUMPADONE",
        "NumPad2" => "NUMPADTWO",
        "NumPad3" => "NUMPADTHREE",
        "NumPad4" => "NUMPADFOUR",
        "NumPad5" => "NUMPADFIVE",
        "NumPad6" => "NUMPADSIX",
        "NumPad7" => "NUMPADSEVEN",
        "NumPad8" => "NUMPADEIGHT",
        "NumPad9" => "NUMPADNINE"
    ];

    if (keyMap.exists(key))
        return keyMap.get(key);

    return key.toUpperCase();
}

// ============================================================
// 检查按键
// ============================================================

function isRestartKeyHeld(keyName:String):Bool {
    if (keyName == null || keyName == "")
        return false;

    var pressed = Reflect.getProperty(FlxG.keys, "pressed");

    if (pressed == null)
        return false;

    return Reflect.getProperty(pressed, keyName) == true;
}

// ============================================================
// 添加对象
// ============================================================

function addToCurrentState(obj:Dynamic):Void {
    if (FlxG.state == null || obj == null)
        return;

    var addMethod = Reflect.field(FlxG.state, "add");

    if (addMethod != null)
        Reflect.callMethod(FlxG.state, addMethod, [obj]);
}

// ============================================================
// 移除对象
// ============================================================

function removeDisplayObject(obj:Dynamic):Void {
    if (obj == null)
        return;

    try {
        if (FlxG.state != null) {
            var removeMethod = Reflect.field(FlxG.state, "remove");

            if (removeMethod != null)
                Reflect.callMethod(FlxG.state, removeMethod, [obj, false]);
        }
    } catch (e:Dynamic) {}

    try {
        obj.destroy();
    } catch (e:Dynamic) {}
}

// ============================================================
// 清理重启 UI
// ============================================================

function clearRestartUI():Void {
    removeDisplayObject(restartProgressBar);
    removeDisplayObject(restartProgressBackground);

    restartProgressBar = null;
    restartProgressBackground = null;
    createdState = null;

    destroyRestartCamera();
}

// ============================================================
// 创建进度条
// ============================================================

function createRestartProgressBar():Void {
    if (FlxG.state == null)
        return;

    if (restartProgressBar != null && createdState == FlxG.state)
        return;

    clearRestartUI();
    createRestartCamera();

    createdState = FlxG.state;

    var barWidth:Int = Std.int(FlxG.width - restartBarMargin * 2);
    var innerWidth:Int = barWidth - restartBarBorder * 2;
    var innerHeight:Int = restartBarHeight - restartBarBorder * 2;

    if (barWidth <= 0 || innerWidth <= 0 || innerHeight <= 0)
        return;

    var x:Float = restartBarMargin;
    var y:Float = restartBarMargin;

    var background = new FlxSprite(x, y);
    background.makeGraphic(barWidth, restartBarHeight, FlxColor.BLACK);
    background.scrollFactor.set(0, 0);
    background.cameras = [restartCamera];
    background.antialiasing = false;

    addToCurrentState(background);
    restartProgressBackground = background;

    var bar = new FlxSprite(
        x + restartBarBorder,
        y + restartBarBorder
    );

    bar.makeGraphic(innerWidth, innerHeight, FlxColor.RED);
    bar.scrollFactor.set(0, 0);
    bar.cameras = [restartCamera];
    bar.antialiasing = false;

    addToCurrentState(bar);
    restartProgressBar = bar;
}

// ============================================================
// 更新进度条
// ============================================================

function updateRestartProgressBar():Void {
    if (restartProgressBar == null)
        return;

    var fullWidth:Int = Std.int(
        FlxG.width
        - restartBarMargin * 2
        - restartBarBorder * 2
    );

    var innerHeight:Int = restartBarHeight - restartBarBorder * 2;

    var progress:Float = 0;

    if (restartHoldDuration > 0)
        progress = restartHoldTime / restartHoldDuration;

    if (progress < 0)
        progress = 0;

    if (progress > 1)
        progress = 1;

    var currentWidth:Int = Std.int(fullWidth * progress);

    restartProgressBar.setGraphicSize(currentWidth, innerHeight);
    restartProgressBar.updateHitbox();

    restartProgressBar.x = restartBarMargin + restartBarBorder;
    restartProgressBar.y = restartBarMargin + restartBarBorder;
}

// ============================================================
// 执行软重启
// ============================================================

function performSoftRestart():Void {
    if (restarting)
        return;

    restarting = true;
    restartHoldTime = 0;

    if (settingChangeTimer != null) {
        settingChangeTimer.cancel();
        settingChangeTimer = null;
    }

    clearRestartUI();

    // 先恢复引擎原始显示状态
    restoreOriginalDisplay();

    // 重置标题状态
    TitleState.initialized = false;
    TitleState.closedState = false;

    if (FlxG.sound.music != null)
        FlxG.sound.music.stop();

    trace('[SoftRestart] Restarting game');

    FlxG.resetGame();
}

// ============================================================
// 初始化
// ============================================================

initializeWideScreen();

// ============================================================
// 每帧更新
// ============================================================

function onUpdate(elapsed:Float):Void {
    if (restarting)
        return;
	initializeWideScreen();
    // 检查宽屏设置
    checkWideScreenSetting();

    // 设置变化等待重启时，不继续处理长按重启
    if (settingChangeTimer != null)
        return;

    var keyName:String = getRestartKey();

    if (keyName == null || restartHoldDuration <= 0) {
        restartHoldTime = 0;
        clearRestartUI();
        return;
    }

    if (FlxG.state == null)
        return;

    if (isRestartKeyHeld(keyName)) {
        restartHoldTime += elapsed * 1000;

        if (restartHoldTime > restartHoldDuration)
            restartHoldTime = restartHoldDuration;

        createRestartProgressBar();
        updateRestartProgressBar();

        if (restartHoldTime >= restartHoldDuration)
            performSoftRestart();
    } else {
        restartHoldTime = 0;
        clearRestartUI();
    }
}

// ============================================================
// 状态切换
// ============================================================

function onStateSwitch():Void {
    clearRestartUI();
    restartHoldTime = 0;

    if (!waitingForTitleRestart)
        restarting = false;
}